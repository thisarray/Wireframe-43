﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum GhostColour
{
    Red,
    Pink,
    Yellow,
    Blue
};

public enum AITechnique
{
    FSM,
    BT,
    StackFSM
};

//-------------------------------------------------------------------------------------------

public class GhostHandler : MonoBehaviour
{
    public const float kAfraidDuration   = 5.0f;
    public AITechnique currentAIApproach = AITechnique.FSM;

    [SerializeField] private List<Ghost>                    ghosts     = new List<Ghost>();
    [SerializeField] private List<FiniteStateMachine>       ghostFSMs  = new List<FiniteStateMachine>();
    [SerializeField] private List<BehaviourTree>            ghostBTs   = new List<BehaviourTree>();
    [SerializeField] private List<FiniteStateMachine_Stack> ghostSFSMs = new List<FiniteStateMachine_Stack>();

    //-------------------------------------------------------------------------------------------

    public Ghost GetGhost(GhostColour colour)
    {
        return ghosts[(int)colour];
    }

    //-------------------------------------------------------------------------------------------

    public AITechnique GetCurrentAIApproach()
    {
        return currentAIApproach;
    }

    //-------------------------------------------------------------------------------------------

    public FiniteStateMachine GetGhostFSM(GhostColour colour)
    {
        return ghostFSMs[(int)colour];
    }

    //-------------------------------------------------------------------------------------------

    public BehaviourTree GetGhostBT(GhostColour colour)
    {
        return ghostBTs[(int)colour];
    }

    //-------------------------------------------------------------------------------------------

    public FiniteStateMachine_Stack GetGhostSFSM(GhostColour colour)
    {
        return ghostSFSMs[(int)colour];
    }

    //-------------------------------------------------------------------------------------------

    public void SetGhostsAfraid()
    {
        for (int i = 0; i < ghosts.Count; i++)
            ghosts[i].SetAfraid(kAfraidDuration);
    }

    //-------------------------------------------------------------------------------------------

    private void Update()
    {
        //Press 1 and we use FSM, press 2 and we use BT.
        if (Input.GetKey(KeyCode.Alpha1))
        {
            currentAIApproach = AITechnique.FSM;
            for (int i = 0; i < ghosts.Count; i++)
            {
                ghostFSMs[i].enabled    = true;
                ghostBTs[i].enabled     = false;
                ghostSFSMs[i].enabled   = false;
            }
        }
        else if (Input.GetKey(KeyCode.Alpha2))
        {
            currentAIApproach = AITechnique.BT;
            for (int i = 0; i < ghosts.Count; i++)
            {
                ghostFSMs[i].enabled    = false;
                ghostBTs[i].enabled     = true;
                ghostSFSMs[i].enabled   = false;
            }
        }
        else if (Input.GetKey(KeyCode.Alpha3))
        {
            currentAIApproach = AITechnique.StackFSM;
            for (int i = 0; i < ghosts.Count; i++)
            {
                ghostFSMs[i].enabled    = false;
                ghostBTs[i].enabled     = false;
                ghostSFSMs[i].enabled   = true;
            }
        }
        else if (Input.GetKeyUp(KeyCode.P))
        {
            GameWorld.GamePaused = !GameWorld.GamePaused;
        }
    }

    //-------------------------------------------------------------------------------------------
}
