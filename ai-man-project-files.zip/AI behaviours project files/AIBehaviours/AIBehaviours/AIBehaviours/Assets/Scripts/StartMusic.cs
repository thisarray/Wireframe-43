﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(AudioSource))]
public class StartMusic : MonoBehaviour
{
    private AudioSource audioSource         = null;

    private bool        startMusicStarted   = false;

    //----------------------------------------------------------------------------------------------

    void Start()
    {
        audioSource = GetComponent<AudioSource>();

        GameWorld.GameBegan = false; 
        startMusicStarted   = false;
    }

    //----------------------------------------------------------------------------------------------

    private void Update()
    {
        if (!GameWorld.GameBegan && !GameWorld.GamePaused)
        {
            if (!startMusicStarted)
            {
                startMusicStarted = true;
                audioSource.Play();
            }
            else
            {
                if(!audioSource.isPlaying)
                    GameWorld.GameBegan = true;
            }
        }
    }

    //----------------------------------------------------------------------------------------------
}
