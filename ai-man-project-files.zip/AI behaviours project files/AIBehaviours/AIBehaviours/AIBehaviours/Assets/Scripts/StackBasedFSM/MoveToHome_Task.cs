﻿using UnityEngine;

public class MoveToHome_Task : Base_Task
{
    private Vector2Int homePos = new Vector2Int(14, 13);
    private bool setForRemoval = false;

    //-------------------------------------------------------------------------------------

    public MoveToHome_Task(Ghost g, Player p) : base(g, p)
    {
        taskName      = "MoveToHome_Task";
        setForRemoval = false;

        OnEnter();
    }

    //-------------------------------------------------------------------------------------

    public override void OnEnter()
    {
        if (ghost)
        {
            ghost.ghostVisuals.SetSpriteSet(SpriteSet.Eyes);
        }
    }

    //-------------------------------------------------------------------------------------

    public override void OnUpdate()
    {
        //This is super simple - Just set the position we want to go to.
        if (ghost)
        {
            ghost.SetCurrentAIString(taskName);

            ghost.SetTargetBoardPosition(homePos);

            ghost.MoveHome();
        }
    }

    //-------------------------------------------------------------------------------------

    public override void OnExit()
    {
        if (ghost)
        {
            ghost.SetEaten(false);
        }
    }

    //-------------------------------------------------------------------------------------

    public override void CheckTransitions(FiniteStateMachine_Stack stack)
    {
        //MOVETOHOME can only move in to EXITHOME, or remove itself.
        if (setForRemoval)
        {
            OnExit();
            stack.PopTask();
        }
        else if (ghost && ghost.GetBoardPosition() == homePos)
        {
            setForRemoval = true;
            stack.PushTask(new ExitHome_Task(ghost, player));
        }

        //Else - Stick with the current task.
    }

    //-------------------------------------------------------------------------------------
}
