﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Base_Task
{
    protected Ghost  ghost  = null;
    protected Player player = null;

    protected string taskName = "Base_Task";

    //-------------------------------------------------------------------------------------

    public Base_Task(Ghost g, Player p)
    {
        ghost  = g;
        player = p;
    }

    //-------------------------------------------------------------------------------------

    public virtual void OnEnter()
    { 
        Debug.Log("BASE_TASK - OnEnter() - Override required");
    }

    //-------------------------------------------------------------------------------------

    public virtual void OnUpdate()
    {
        if (ghost)
            ghost.SetCurrentAIString("BASE_TASK");

        Debug.Log("BASE_TASK - OnUpdate() - Override required");
    }

    //-------------------------------------------------------------------------------------

    public virtual void OnExit()
    {
        Debug.Log("BASE_TASK - OnExit() - Override required");
    }

    //-------------------------------------------------------------------------------------

    public virtual void CheckTransitions(FiniteStateMachine_Stack stack)
    {
        Debug.Log("BASE_TASK - CheckTransitions() - Override required");
    }

    //-------------------------------------------------------------------------------------

    public string GetStringID()
    {
        return taskName;
    }

    //-------------------------------------------------------------------------------------
}
