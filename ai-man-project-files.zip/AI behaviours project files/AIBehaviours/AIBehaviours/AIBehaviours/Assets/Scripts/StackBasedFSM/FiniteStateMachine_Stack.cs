﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------
//           Example: FSM Stack Structure
//-------------------------------------------------------------
//
//                -------------   
//                | EXIT_HOME |     <-Task being updated
//               ----------------    
//               | MOVE_TO_HOME |
//               ----------------        
//               |     EVADE    |
//               ----------------
//                |    CHASE   |
//                --------------
//
//--------------------------------------------------------------

public enum GhostTask
{
    Chase,
    Evade,
    ReturnToHome,
    ExitHome
};

//-------------------------------------------------------------------------------------------
[RequireComponent(typeof(Ghost))]
public class FiniteStateMachine_Stack : MonoBehaviour
{
    private Stack<Base_Task> taskStack      = new Stack<Base_Task>();
    public ChaseType         typeOfChase    = ChaseType.PlayerPosition;

    private Ghost            ghost          = null;
    private Player           player         = null;

    //-------------------------------------------------------------------------------------------

    void Start()
    {
        ghost = GetComponent<Ghost>();
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();

        //To kick things off we need to push enter the Chase state.
        taskStack.Push(new Chase_Task(ghost, player, typeOfChase));
    }

    //-------------------------------------------------------------------------------------------

    void Update()
    {
        if (GameWorld.GameBegan && !GameWorld.GamePaused)
        {
            //Do we need to transition out of the current task.
            taskStack.Peek().CheckTransitions(this);

            //Update the task on the top of the stack.
            taskStack.Peek().OnUpdate();
        }
    }

    //-------------------------------------------------------------------------------------------

    public void PushTask(Base_Task newTask)
    {
        taskStack.Push(newTask);
    }

    //-------------------------------------------------------------------------------------------

    public Base_Task PeekTask()
    {
        return taskStack.Peek();
    }

    //-------------------------------------------------------------------------------------------

    public void PopTask()
    {
        taskStack.Pop();
    }

    //-------------------------------------------------------------------------------------------

    public string GetTaskFromStackAt(int index)
    {
        if (index < taskStack.Count)
        {
            int i = 0;
            foreach (Base_Task task in taskStack)
            {
                if (i == index)
                    return task.GetStringID();
                i++;
            }
        }

        return "";
    }

    //-------------------------------------------------------------------------------------------

    public int GetStackSize()
    {
        return taskStack.Count;
    }

    //-------------------------------------------------------------------------------------------
}
