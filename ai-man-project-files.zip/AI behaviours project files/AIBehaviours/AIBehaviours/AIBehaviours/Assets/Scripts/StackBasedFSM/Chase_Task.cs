﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//-------------------------------------------------------------------------------------

public class Chase_Task : Base_Task
{
    private ChaseType   chaseType   = ChaseType.PlayerPosition;
    private Player      player      = null;

    //-------------------------------------------------------------------------------------

    public Chase_Task(Ghost g, Player p, ChaseType typeOfChase) : base(g, p)
    {
        taskName    = "Chase_Task";
        chaseType   = typeOfChase;
        player      = p;

        OnEnter();
    }

    //-------------------------------------------------------------------------------------

    public override void OnEnter()
    {
    }

    //-------------------------------------------------------------------------------------

    public override void OnUpdate()
    {
        if (ghost)
        {
            ghost.SetCurrentAIString(taskName);

            switch (chaseType)
            {
                case ChaseType.PlayerPosition:
                    ghost.SetTargetBoardPosition(player.GetBoardPosition());
                break;

                //Check which direction the player is facing, and set the position ahead.
                case ChaseType.BehindPlayer:
                    Vector2Int positionBehindPlayer = new Vector2Int();
                    switch (player.GetDirection())
                    {
                        case Direction.Left:
                            positionBehindPlayer = player.GetBoardPosition() + new Vector2Int(1, 0);
                        break;

                        case Direction.Right:
                            positionBehindPlayer = player.GetBoardPosition() + new Vector2Int(-1, 0);
                        break;

                        case Direction.Up:
                            positionBehindPlayer = player.GetBoardPosition() + new Vector2Int(0, 1);
                        break;

                        case Direction.Down:
                            positionBehindPlayer = player.GetBoardPosition() + new Vector2Int(0, -1);
                        break;
                    }

                    //Check this position is valid, if not default to the players position.
                    if (GameWorld.IsCellAccessible(positionBehindPlayer))
                        ghost.SetTargetBoardPosition(positionBehindPlayer);
                    else
                        ghost.SetTargetBoardPosition(player.GetBoardPosition());
                break;

                //Check which direction the player is facing, and set the position ahead.
                case ChaseType.AheadOfPlayer:
                    Vector2Int positionAheadOfPlayer = new Vector2Int();
                    switch (player.GetDirection())
                    {
                        case Direction.Left:
                            positionAheadOfPlayer = player.GetBoardPosition()+new Vector2Int(-1, 0);
                        break;

                        case Direction.Right:
                            positionAheadOfPlayer = player.GetBoardPosition() + new Vector2Int(1, 0);
                         break;

                        case Direction.Up:
                            positionAheadOfPlayer = player.GetBoardPosition() + new Vector2Int(0, -1);
                         break;

                        case Direction.Down:
                            positionAheadOfPlayer = player.GetBoardPosition() + new Vector2Int(0, 1);
                        break;
                    }

                    //Check this position is valid, if not default to the players position.
                    if (GameWorld.IsCellAccessible(positionAheadOfPlayer))
                        ghost.SetTargetBoardPosition(positionAheadOfPlayer);
                    else
                        ghost.SetTargetBoardPosition(player.GetBoardPosition());
                break;

                case ChaseType.Random:
                    //This changes every frame, but the ghost will keep heading in the same direction until it
                    //reaches an intersection.
                    ghost.SetTargetBoardPosition(new Vector2Int(Random.Range(0, 28), Random.Range(0, 32)));
                break;

                default:
                break;
            }

            ghost.Move();
        }
    }

    //-------------------------------------------------------------------------------------

    public override void OnExit()
    {

    }

    //-------------------------------------------------------------------------------------

    public override void CheckTransitions(FiniteStateMachine_Stack stack)
    {
        //CHASE is our default Task, so it can never be removed from the stack.
        //CHASE can move into EVADE or MoveToHome, or at the start of the game ExitHome.
        if (ghost)
        {
            if (ghost.IsInHome())
                stack.PushTask(new ExitHome_Task(ghost, player));
            else if (ghost.HasBeenEaten())
                stack.PushTask(new MoveToHome_Task(ghost, player));
            else if (ghost.IsPowerPillActive())
                stack.PushTask(new Evade_Task(ghost, player));
        }

        //Else - Stick with the current task.
    }

    //-------------------------------------------------------------------------------------
}
