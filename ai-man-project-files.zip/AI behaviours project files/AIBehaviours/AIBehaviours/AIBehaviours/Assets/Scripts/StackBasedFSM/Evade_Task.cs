﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Evade_Task : Base_Task
{
    Vector2Int randomEvadePosition = new Vector2Int();

    //-------------------------------------------------------------------------------------

    public Evade_Task(Ghost g, Player p) : base(g, p)
    {
        taskName = "Evade_Task";

        //Choose a random position off the map to evade to - The ghost will never reach it,
        // but will keep circling the map in search of it.
        System.Random rnd = new System.Random();
        randomEvadePosition.x = rnd.Next(0, 1) * GameWorld.BoardRows;
        randomEvadePosition.x = rnd.Next(0, 1) * GameWorld.BoardColumns;

        OnEnter();
    }

    //-------------------------------------------------------------------------------------

    public override void OnEnter()
    {
        if (ghost)
        { 
            ghost.ghostVisuals.SetSpriteSet(SpriteSet.Evading);
        }
    }

    //-------------------------------------------------------------------------------------

    public override void OnUpdate()
    {
        //This is super simple - Just set the position we want to go to.
        if (ghost)
        {
            ghost.SetCurrentAIString(taskName);

            ghost.SetTargetBoardPosition(randomEvadePosition);

            ghost.Move();
        }
    }

    //-------------------------------------------------------------------------------------

    public override void OnExit()
    {
        if (ghost && !ghost.HasBeenEaten())
        {
            ghost.ghostVisuals.SetSpriteSet(SpriteSet.Chasing);
        }
    }

    //-------------------------------------------------------------------------------------

    public override void CheckTransitions(FiniteStateMachine_Stack stack)
    {
        //EVADE can move into MOVETOHOME, or remove itself.
        if (ghost)
        {
            if (ghost.HasBeenEaten())
                stack.PushTask(new MoveToHome_Task(ghost, player));
            else if (!ghost.IsPowerPillActive())
            {
                OnExit();
                stack.PopTask();
            }

            //Else - Stick with the current task.
        }

        //Else - Stick with the current task.
    }

    //-------------------------------------------------------------------------------------
}
