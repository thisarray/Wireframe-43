﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AIVisuals_StackFSM : MonoBehaviour
{
    [SerializeField] private FiniteStateMachine_Stack   ghostSFSM           = null;

    [SerializeField] private List<Text>                 taskStackText       = new List<Text>();
    [SerializeField] private List<Image>                taskStackImages     = new List<Image>();

    [SerializeField] private Color                      activeColour        = Color.black;
    [SerializeField] private Color                      inactiveColour      = Color.white;

    //-------------------------------------------------------------------------------------

    private void OnEnable()
    {
        DeactivateAll();
    }

    //-------------------------------------------------------------------------------------

    void DeactivateAll()
    {
        for (int i = 0; i < taskStackImages.Count; i++)
        {
            taskStackText[i].text    = "";
            taskStackImages[i].color = inactiveColour;
        }        
    }

    //-------------------------------------------------------------------------------------

    void Update()
    {
        DeactivateAll();

        if (ghostSFSM && ghostSFSM.GetStackSize() > 0)
        {
            for (int i = 0; i < ghostSFSM.GetStackSize(); i++)
            {
                taskStackText[i].text = ghostSFSM.GetTaskFromStackAt(i);
            }

            //Top of the stack is always the active task.
            taskStackImages[0].color = activeColour;
        }
    }

    //-------------------------------------------------------------------------------------
}
