﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExitHome_Task : Base_Task
{
    private Vector2Int exitPos = new Vector2Int(14, 11);

    //-------------------------------------------------------------------------------------

    public ExitHome_Task(Ghost g, Player p) : base(g, p)
    {
        taskName = "ExitHome_Task";

        OnEnter();
    }

    //-------------------------------------------------------------------------------------

    public override void OnEnter()
    {
        if (ghost)
        {
            ghost.ghostVisuals.SetSpriteSet(SpriteSet.Chasing);
        }
    }

    //-------------------------------------------------------------------------------------

    public override void OnUpdate()
    {
        //This is super simple - Just set the position we want to go to.
        if (ghost)
        {
            ghost.SetCurrentAIString(taskName);

            ghost.SetTargetBoardPosition(exitPos);

            ghost.MoveHome();
        }
    }

    //-------------------------------------------------------------------------------------

    public override void OnExit()
    {

    }

    //-------------------------------------------------------------------------------------

    public override void CheckTransitions(FiniteStateMachine_Stack stack)
    {
        //EXITHOME can only do its purpose or remove itself.
        if (ghost && ghost.GetBoardPosition() == exitPos)
        {
            OnExit();
            stack.PopTask();
        }

        //Else - Stick with the current task.
    }

    //-------------------------------------------------------------------------------------
}