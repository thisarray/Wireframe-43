﻿using UnityEngine;

public class Leaf_MoveToPlayer : TreeNode_Base
{
    private const float kMaxDuration = 10.0f;
    private float       duration     = kMaxDuration;

    //------------------------------------------------------------------------------

    public Leaf_MoveToPlayer()
    {

    }

    //------------------------------------------------------------------------------

    public override Status OnUpdate(Ghost ghost, Player player)
    {
        duration -= Time.deltaTime;

        //This is super simple - Just set the position we want to go to.
        if (ghost)
        {
            ghost.AddToCombinedAIString("Leaf_MoveToPlayer");

            ghost.ghostVisuals.SetSpriteSet(SpriteSet.Chasing);
            ghost.SetTargetBoardPosition(player.GetBoardPosition());
            ghost.Move();
        }

        //After the desired duration, we will return the status FAILURE to allow our parent node to select
        //another way to chase the player.
        if (duration <= 0.0f)
        {
            //Reset for next time.
            duration = kMaxDuration;

            //We moved in this manner for the duration
            return Status.SUCCESS;
        }
        else
            return Status.RUNNING;
    }

    //------------------------------------------------------------------------------
}