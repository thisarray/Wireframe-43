﻿using UnityEngine;

public class Leaf_MoveBehindPlayer : TreeNode_Base
{
    private const float kMaxDuration = 10.0f;
    private float       duration     = kMaxDuration;

    //------------------------------------------------------------------------------

    public Leaf_MoveBehindPlayer()
    {

    }

    //------------------------------------------------------------------------------

    public override Status OnUpdate(Ghost ghost, Player player)
    {
        duration -= Time.deltaTime;

        //This is super simple - Just set the position we want to go to.
        if (ghost)
        {
            ghost.AddToCombinedAIString("Leaf_MoveBehindPlayer");

            ghost.ghostVisuals.SetSpriteSet(SpriteSet.Chasing);

            Vector2Int positionBehindPlayer = new Vector2Int();
            switch (player.GetDirection())
            {
                case Direction.Left:
                    positionBehindPlayer = player.GetBoardPosition() + new Vector2Int(1, 0);
                break;

                case Direction.Right:
                    positionBehindPlayer = player.GetBoardPosition() + new Vector2Int(-1, 0);
                break;

                case Direction.Up:
                    positionBehindPlayer = player.GetBoardPosition() + new Vector2Int(0, 1);
                break;

                case Direction.Down:
                    positionBehindPlayer = player.GetBoardPosition() + new Vector2Int(0, -1);
                break;
            }

            //Check this position is valid, if not default to the players position.
            if (GameWorld.IsCellAccessible(positionBehindPlayer))
                ghost.SetTargetBoardPosition(positionBehindPlayer);
            else
                ghost.SetTargetBoardPosition(player.GetBoardPosition());

            ghost.Move();
        }

        //After the desired duration, we will return the status FAILURE to allow our parent node to select
        //another way to chase the player.
        if (duration <= 0.0f)
        {
            //Reset for next time.
            duration = kMaxDuration;

            //We moved in this manner for the duration
            return Status.SUCCESS;
        }
        else
            return Status.RUNNING;
    }

    //------------------------------------------------------------------------------
}
