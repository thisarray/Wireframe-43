﻿using UnityEngine;
using System;

public class Leaf_Evade : TreeNode_Base
{
    Vector2Int randomEvadePosition = new Vector2Int();

    //------------------------------------------------------------------------------

    public Leaf_Evade()
    {
        //Choose a random position off the map to evade to - The ghost will never reach it,
        // but will keep circling the map in search of it.
        System.Random rnd = new System.Random();
        randomEvadePosition.x = rnd.Next(0,1) * GameWorld.BoardRows;
        randomEvadePosition.x = rnd.Next(0, 1) * GameWorld.BoardColumns;
    }

    //------------------------------------------------------------------------------

    public override Status OnUpdate(Ghost ghost, Player player)
    {
        //This is super simple - Just set the position we want to go to.
        if (ghost)
        {
            ghost.AddToCombinedAIString("Leaf_Evade");

            ghost.ghostVisuals.SetSpriteSet(SpriteSet.Evading);
            ghost.SetTargetBoardPosition(randomEvadePosition);

            ghost.Move();
        }

        //Se don't expect the ghost to actually reach this position (its off the board), but
        //it needs to keep trying until the power pill has worn off (Parent will handle this)
        return Status.RUNNING;
    }

    //------------------------------------------------------------------------------
}
