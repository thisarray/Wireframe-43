﻿using UnityEngine;

public class Leaf_ExitHome : TreeNode_Base
{
    private Vector2Int exitPos = new Vector2Int(14, 11);

    //------------------------------------------------------------------------------

    public Leaf_ExitHome()
    {

    }

    //------------------------------------------------------------------------------

    public override Status OnUpdate(Ghost ghost, Player player)
    {
        //This is super simple - Just set the position we want to go to.
        if (ghost)
        {
            ghost.AddToCombinedAIString("Leaf_ExitHome");

            ghost.ghostVisuals.SetSpriteSet(SpriteSet.Chasing);
            ghost.SetTargetBoardPosition(exitPos);

            ghost.MoveHome();
        }

        //Return a status to show our progress. (Failure not an option).
        if (ghost.GetBoardPosition() == exitPos)
            return Status.SUCCESS;
        else
            return Status.RUNNING;
    }

    //------------------------------------------------------------------------------
}