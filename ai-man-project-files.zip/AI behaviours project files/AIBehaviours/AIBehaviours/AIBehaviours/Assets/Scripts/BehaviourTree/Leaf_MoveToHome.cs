﻿using UnityEngine;

public class Leaf_MoveToHome : TreeNode_Base
{
    private Vector2Int homePos = new Vector2Int(14, 13);

    //------------------------------------------------------------------------------

    public Leaf_MoveToHome()
    {

    }

    //------------------------------------------------------------------------------

    public override Status OnUpdate(Ghost ghost, Player player)
    {
        //This is super simple - Just set the position we want to go to.
        if (ghost)
        {
            ghost.ghostVisuals.SetSpriteSet(SpriteSet.Eyes);
            ghost.SetTargetBoardPosition(homePos);

            ghost.MoveHome();
        }

        //Return a status to show our progress. (Failure not an option).
        if (ghost.GetBoardPosition() == homePos || !ghost.HasBeenEaten())
        {
            ghost.SetEaten(false);
            return Status.SUCCESS;
        }
        else
        {
            ghost.AddToCombinedAIString("Leaf_MoveToHome");
            return Status.RUNNING;
        }
    }

    //------------------------------------------------------------------------------
}