﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Leaf_MoveToRandomPosition : TreeNode_Base
{
    private const float kMaxDuration = 10.0f;
    private float duration = kMaxDuration;

    Vector2Int randomPosition = new Vector2Int();

    //------------------------------------------------------------------------------

    public Leaf_MoveToRandomPosition()
    {
        ResetPrivatePosition();
    }

    //------------------------------------------------------------------------------

    private void ResetPrivatePosition()
    {
        System.Random rnd = new System.Random();
        randomPosition.x = rnd.Next(1, GameWorld.BoardRows - 2);
        randomPosition.x = rnd.Next(1, GameWorld.BoardColumns - 2);
    }

    //------------------------------------------------------------------------------

    public override Status OnUpdate(Ghost ghost, Player player)
    {
        duration -= Time.deltaTime;

        //This is super simple - Just set the position we want to go to.
        if (ghost)
        {
            ghost.AddToCombinedAIString("Leaf_MoveToRandomPosition");

            ghost.ghostVisuals.SetSpriteSet(SpriteSet.Chasing);
            ghost.SetTargetBoardPosition(player.GetBoardPosition());
            ghost.Move();
        }

        //After the desired duration, we will return the status FAILURE to allow our parent node to select
        //another way to chase the player.
        if (duration <= 0.0f)
        {
            //Reset for next time.
            duration = kMaxDuration;
            ResetPrivatePosition();

            //We moved in this manner for the duration
            return Status.SUCCESS;
        }
        else
            return Status.RUNNING;
    }

    //------------------------------------------------------------------------------
}
