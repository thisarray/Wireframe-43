﻿using UnityEngine;

public class Leaf_MoveToBoardPosition : TreeNode_Base
{
    private Vector2Int targetPosition;

    //------------------------------------------------------------------------------

    public Leaf_MoveToBoardPosition(Vector2Int positionToMoveTo)
    {
        targetPosition = positionToMoveTo;
    }

    //------------------------------------------------------------------------------

    public override Status OnUpdate(Ghost ghost, Player player)
    {
        if (ghost)
        {
            ghost.AddToCombinedAIString("Leaf_MoveToBoardPosition");

            ghost.SetTargetBoardPosition(targetPosition);

            ghost.Move();

            if (ghost.GetBoardPosition() == targetPosition)
                return Status.SUCCESS;
            else
                return Status.RUNNING;
        }
        else
            return Status.FAILURE;
    }

    //------------------------------------------------------------------------------
}