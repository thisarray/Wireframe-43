﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MenuOptions : MonoBehaviour
{
    [SerializeField] private Canvas     startCanvas     = null;
    [SerializeField] private Canvas     endCanvas       = null;
    [SerializeField] private GameObject gameEntity      = null;

    [SerializeField] private Text       winLossMessage  = null;

    //-------------------------------------------------------------------------------------

    public void StartGame()
    {
        gameEntity.SetActive(true);
        startCanvas.gameObject.SetActive(false);
        endCanvas.gameObject.SetActive(false);
    }

    //-------------------------------------------------------------------------------------

    public void RestartGame()
    {
        SceneManager.LoadScene("GameScene");
    }

    //-------------------------------------------------------------------------------------

    public void EndGame(bool winLoss)
    {
        if (winLoss)
            winLossMessage.text = "YOU WIN";
        else
            winLossMessage.text = "YOU LOSE";

        gameEntity.SetActive(false);
        startCanvas.gameObject.SetActive(false);
        endCanvas.gameObject.SetActive(true);
    }

    //-------------------------------------------------------------------------------------
}
